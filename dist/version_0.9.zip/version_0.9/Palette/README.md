# Path for inkscape palette

...\Inkscape\share\palettes\Icarex.gpl

# Color templates and overview

IcarexOverview.svg

